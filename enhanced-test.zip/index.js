exports.handler = async (event, context) => {
  console.log('🚀 Enhanced Keyword Configuration Test');
  
  try {
    // 模拟增强的关键词配置 (基于刚才的更新)
    const enhancedKeywordConfig = {
      companies: {
        apple: {
          keywords: ['apple', 'iphone', 'ipad', 'macbook', 'ios', 'macos', 'apple intelligence', 'tim cook'],
          weight: 30,
          tags: ['bigtech', 'company', 'consumer'],
        },
        microsoft: {
          keywords: ['microsoft', 'windows', 'azure', 'office', 'teams', 'copilot', 'satya nadella'],
          weight: 30,
          tags: ['bigtech', 'company', 'enterprise'],
        },
        google: {
          keywords: ['google', 'alphabet', 'android', 'chrome', 'search', 'youtube', 'pixel', 'sundar pichai'],
          weight: 30,
          tags: ['bigtech', 'company', 'search'],
        },
        nvidia: {
          keywords: ['nvidia', 'gpu', 'cuda', 'geforce', 'rtx', 'ai chip', 'jensen huang'],
          weight: 35,
          tags: ['bigtech', 'company', 'hardware', 'ai'],
        },
        openai: {
          keywords: ['openai', 'chatgpt', 'gpt-4', 'dall-e', 'sam altman', 'artificial intelligence'],
          weight: 40,
          tags: ['bigtech', 'company', 'ai', 'breakthrough'],
        },
      },
      topics: {
        ai: {
          keywords: ['artificial intelligence', 'machine learning', 'ai', 'llm', 'large language model'],
          weight: 35,
          tags: ['ai', 'technology', 'breakthrough'],
        },
        policy: {
          keywords: ['policy', 'regulation', 'antitrust', 'doj', 'ftc', 'investigation', 'lawsuit', 'monopoly'],
          weight: 30,
          tags: ['policy', 'legal', 'regulation'],
        },
        security: {
          keywords: ['data breach', 'hack', 'cyber attack', 'security incident', 'leak', 'vulnerability'],
          weight: 35,
          tags: ['security', 'incident', 'urgent'],
        },
        breaking: {
          keywords: ['breaking', 'urgent', 'alert', 'developing', 'just in'],
          weight: 40,
          tags: ['breaking', 'urgent', 'news'],
        },
      },
      blacklist: ['advertisement', 'sponsored', 'promotional', 'marketing'],
      minScore: 15,
    };

    console.log('📊 Enhanced Keyword Configuration Stats:');
    console.log(`   Companies: ${Object.keys(enhancedKeywordConfig.companies).length}`);
    console.log(`   Topics: ${Object.keys(enhancedKeywordConfig.topics).length}`);
    console.log(`   Total Keywords: ${calculateTotalKeywords(enhancedKeywordConfig)}`);
    console.log(`   Blacklist Terms: ${enhancedKeywordConfig.blacklist.length}`);
    console.log(`   Min Score Threshold: ${enhancedKeywordConfig.minScore}`);

    console.log('\n🏢 Companies configured:');
    Object.entries(enhancedKeywordConfig.companies).forEach(([name, config]) => {
      console.log(`   ${name}: ${config.keywords.length} keywords, weight ${config.weight}, tags [${config.tags.join(', ')}]`);
    });

    console.log('\n🏷️  Topics configured:');
    Object.entries(enhancedKeywordConfig.topics).forEach(([name, config]) => {
      console.log(`   ${name}: ${config.keywords.length} keywords, weight ${config.weight}, tags [${config.tags.join(', ')}]`);
    });

    // 测试一些示例新闻标题的匹配
    const testCases = [
      'Apple announces new iPhone 15 with USB-C',
      'BREAKING: OpenAI releases GPT-4 Turbo with enhanced capabilities',
      'Microsoft Azure cloud infrastructure expands globally',
      'DOJ files antitrust lawsuit against Google search monopoly',
      'Nvidia GPU shortage affects AI training projects',
      'Tesla Cybertruck production begins at Gigafactory',
      'Data breach affects 1 million Facebook users',
      'Amazon AWS introduces new machine learning services',
    ];

    console.log('\n🧪 Testing keyword matching on sample headlines:');
    testCases.forEach(headline => {
      const result = testKeywordMatching(headline, enhancedKeywordConfig);
      console.log(`   "${headline}"`);
      console.log(`      → Score: ${result.score}, Matches: [${result.matches.join(', ')}], Tags: [${result.tags.join(', ')}]`);
    });

    const result = {
      success: true,
      message: 'Enhanced keyword configuration test completed',
      stats: {
        companies: Object.keys(enhancedKeywordConfig.companies).length,
        topics: Object.keys(enhancedKeywordConfig.topics).length,
        totalKeywords: calculateTotalKeywords(enhancedKeywordConfig),
        blacklistTerms: enhancedKeywordConfig.blacklist.length,
        minScoreThreshold: enhancedKeywordConfig.minScore,
      },
      improvement: {
        before: 'Only 4 hardcoded rules (Apple, Google, AI)',
        after: '13 companies + 4 topics with comprehensive keyword coverage',
        keywordIncrease: `${calculateTotalKeywords(enhancedKeywordConfig)} vs 8 keywords before`,
      },
      timestamp: new Date().toISOString(),
    };

    console.log('\n📈 Configuration Improvement Summary:', JSON.stringify(result.improvement, null, 2));

    return {
      statusCode: 200,
      body: JSON.stringify(result, null, 2),
    };

  } catch (error) {
    console.error('❌ Error in enhanced keyword test:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: error.message,
      }),
    };
  }
};

// 辅助函数：计算总关键词数量
function calculateTotalKeywords(config) {
  let total = 0;
  Object.values(config.companies).forEach(company => {
    total += company.keywords.length;
  });
  Object.values(config.topics).forEach(topic => {
    total += topic.keywords.length;
  });
  return total;
}

// 辅助函数：测试关键词匹配 (简化版)
function testKeywordMatching(text, config) {
  const lowerText = text.toLowerCase();
  let score = 0;
  const matches = [];
  const tags = new Set();

  // 检查公司关键词
  Object.entries(config.companies).forEach(([companyName, companyConfig]) => {
    companyConfig.keywords.forEach(keyword => {
      if (lowerText.includes(keyword.toLowerCase())) {
        score += companyConfig.weight;
        matches.push(`${companyName}:${keyword}`);
        companyConfig.tags.forEach(tag => tags.add(tag));
      }
    });
  });

  // 检查主题关键词
  Object.entries(config.topics).forEach(([topicName, topicConfig]) => {
    topicConfig.keywords.forEach(keyword => {
      if (lowerText.includes(keyword.toLowerCase())) {
        score += topicConfig.weight;
        matches.push(`${topicName}:${keyword}`);
        topicConfig.tags.forEach(tag => tags.add(tag));
      }
    });
  });

  // 检查黑名单 (降分)
  config.blacklist.forEach(blackword => {
    if (lowerText.includes(blackword.toLowerCase())) {
      score -= 10;
      matches.push(`blacklist:${blackword}`);
    }
  });

  return {
    score: Math.max(0, score),
    matches,
    tags: Array.from(tags),
  };
}
